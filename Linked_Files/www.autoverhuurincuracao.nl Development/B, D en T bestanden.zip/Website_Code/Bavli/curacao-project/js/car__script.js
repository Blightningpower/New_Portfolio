let json = [
	{
		picture__src: "../img/auto's/toyota__rush.png",
		car__logo: "../img/auto-logo's/toyota.png",
		car__name: "Toyota Rush",
		price: "71,50",
		transmission: "Automaat",
		people: "7",
		car__link: "../html/product.html",
	},
	{
		picture__src: "../img/auto's/chevrolet__captiva.png",
		car__logo: "../img/auto-logo's/chevrolet.png",
		car__name: "Chevrolet Captiva",
		price: "61,-",
		transmission: "Automaat",
		people: "5",
		car__link: "../html/product.html",
	},
	{
		picture__src: "../img/auto's/suzuki__jimmy.png",
		car__logo: "../img/auto-logo's/suzuki.png",
		car__name: "Suzuki Jimmy",
		price: "61,-",
		transmission: "Automaat",
		people: "4",
		car__link: "../html/product.html",
	},
	{
		picture__src: "../img/auto's/suzuki__jimmy.png",
		car__logo: "../img/auto-logo's/suzuki.png",
		car__name: "Suzuki Jimmy",
		price: "61,-",
		transmission: "Automaat",
		people: "4",
		car__link: "../html/product.html",
	},
	{
		picture__src: "../img/auto's/chevrolet__captiva.png",
		car__logo: "../img/auto-logo's/chevrolet.png",
		car__name: "Chevrolet Captiva",
		price: "61,-",
		transmission: "Automaat",
		people: "5",
		car__link: "../html/product.html",
	},
	{
		picture__src: "../img/auto's/toyota__rush.png",
		car__logo: "../img/auto-logo's/toyota.png",
		car__name: "Toyota Rush",
		price: "71,50",
		transmission: "Automaat",
		people: "7",
		car__link: "../html/product.html",
	},
	{
		picture__src: "../img/auto's/chevrolet__captiva.png",
		car__logo: "../img/auto-logo's/chevrolet.png",
		car__name: "Chevrolet Captiva",
		price: "61,-",
		transmission: "Automaat",
		people: "5",
		car__link: "../html/product.html",
	},
	{
		picture__src: "../img/auto's/toyota__rush.png",
		car__logo: "../img/auto-logo's/toyota.png",
		car__name: "Toyota Rush",
		price: "71,50",
		transmission: "Automaat",
		people: "7",
		car__link: "../html/product.html",
	},
	{
		picture__src: "../img/auto's/suzuki__jimmy.png",
		car__logo: "../img/auto-logo's/suzuki.png",
		car__name: "Suzuki Jimmy",
		price: "61,-",
		transmission: "Automaat",
		people: "4",
		car__link: "../html/product.html",
	},
	{
		picture__src: "../img/auto's/toyota__rush.png",
		car__logo: "../img/auto-logo's/toyota.png",
		car__name: "Toyota Rush",
		price: "71,50",
		transmission: "Automaat",
		people: "7",
		car__link: "../html/product.html",
	},
	{
		picture__src: "../img/auto's/suzuki__jimmy.png",
		car__logo: "../img/auto-logo's/suzuki.png",
		car__name: "Suzuki Jimmy",
		price: "61,-",
		transmission: "Automaat",
		people: "4",
		car__link: "../html/product.html",
	},
	{
		picture__src: "../img/auto's/chevrolet__captiva.png",
		car__logo: "../img/auto-logo's/chevrolet.png",
		car__name: "Chevrolet Captiva",
		price: "61,-",
		transmission: "Automaat",
		people: "5",
		car__link: "../html/product.html",
	},
];

console.log(json);
// Create an empty string to store the HTML for all cars
let carHtml = "";

json.forEach((cars, index) => {
    carHtml += `
  <a href="${cars.car__link}">
    <div class="car__cards">
      <img class="car__cardsImg" src="${cars.picture__src}" alt="${cars.car__name}" width="100%"/>
      <img src="${cars.car__logo}" alt="${cars.car__name}" class="car__logos" />
      <div class="reserveren__card__content">
        <div class="reserveren__card__top__content">
          <span><i class="fa-solid fa-user"></i> ${cars.people} Persoons auto</span>
          <span><i class="fa-solid fa-car"></i> ${cars.transmission}</span>
        </div>
        <div class="reserveren__card__bottom__content">
          <b>${cars.car__name}</b>
          <b class="reserveren__card__highlight">€ ${cars.price}</b>
        </div>
      </div>
    </div>
  </a>`;
});

document.querySelector(".reserveren__cards").innerHTML = carHtml;

