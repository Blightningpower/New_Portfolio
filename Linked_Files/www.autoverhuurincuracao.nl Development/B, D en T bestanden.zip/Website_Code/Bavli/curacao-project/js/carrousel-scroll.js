const marquee = document.querySelector('.marquee');

function duplicateItems() {
    const items = marquee.innerHTML;
    marquee.innerHTML += items;
}

duplicateItems(); // Duplicate the items to create a continuous loop

function startSlider() {
    const speed = 1; // Adjust the speed as needed
    const itemWidth = marquee.children[0].offsetWidth + 16; // Width of a single item plus the gap
    let position = 0;

    function move() {
        position -= speed;
        marquee.style.transform = `translateX(${position}px)`;

        // Check if we need to reset the position
        if (position < -marquee.scrollWidth / 2) {
            position = 0;
        }
    }

    setInterval(move, 20); // Adjust the interval as needed
}

startSlider();

 // Get the ul element
 const ulElement = document.querySelector('.marquee');

// Get the list items
const listItems = ulElement.querySelectorAll('li');

// Duplicate and append list items 1000 times
for (let i = 0; i < 1000; i++) {
  listItems.forEach(originalItem => {
	const clonedItem = originalItem.cloneNode(true);
	ulElement.appendChild(clonedItem);
  });
}