//script for inputfields

// Get today's date
var today = new Date();

// Set the min attribute to today's date
var minDate = today.toISOString().split('T')[0];
document.querySelector('.dateInput').min = minDate;

// Set the max attribute to a year from today's date
var maxDate = new Date(today);
maxDate.setFullYear(today.getFullYear() + 1);
var maxDateString = maxDate.toISOString().split('T')[0];
document.querySelector('.dateInput').max = maxDateString;

document.getElementById('quantity').addEventListener('focus', function() {
    document.querySelector('.quantityContainer').classList.add('focused');
  });

  document.getElementById('quantity').addEventListener('blur', function() {
    document.querySelector('.quantityContainer').classList.remove('focused');
  });
// ---
// CTA
function whatsApp() {
    window.open('https://wa.me/59994610659', '_blank');
}
// ---